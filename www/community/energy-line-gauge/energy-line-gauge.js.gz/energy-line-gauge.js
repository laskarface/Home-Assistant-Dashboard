export{J as EnergyLineGauge}from"./elg-energy-line-gauge-BGud3qN0.js";
